package com.example.quandry

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
